import Header from "./section/Header"
import Main from "./section/Main"
import Portfolio from "./section/portfolio/Portfolio"
import About from "./section/About"
import Contact from "./section/Contact"
import Footer from "./section/footer/Footer"

import "../styles/style.css"

const HomePage = () => {
    return <>
        <Header />
        <Main />
        <Portfolio />
        <About />
        <Contact />
        <Footer />
    </>
}

export default HomePage