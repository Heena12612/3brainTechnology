import { useState } from "react";

const Navbar = () => {

    const [active, setActive] = useState("");
    const menu = [{
        name: 'Portfolio',
        href: "#portfolio"
    }, {
        name: 'About',
        href: "#about"
    },
    {
        name: 'Contact',
        href: "#contact"
    }]


    return <div className="collapse navbar-collapse" id="navbarResponsive">
    <ul className="navbar-nav ms-auto">
        {
            menu.map((items, index) => {
                return <li className="nav-item mx-0 mx-lg-1" key={index} onClick={() => { setActive(index) }}><a className={active === index ? "nav-link py-3 px-0 px-lg-3 rounded active" : "nav-link py-3 px-0 px-lg-3 rounded"} href={items.href}>{items.name}</a></li>

            })

        }
        
    </ul>
</div>
}

export default Navbar