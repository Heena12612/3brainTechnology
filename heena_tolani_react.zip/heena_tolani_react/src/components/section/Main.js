import Divider from "../ui/Divider"

const Main = () => {
    return (
        <header className="masthead bg-primary text-white text-center">
            <div className="container d-flex align-items-center flex-column">

                <img className="masthead-avatar mb-5" src="assets/img/avataaars.svg" alt="..." />

                <h1 className="masthead-heading text-uppercase mb-0">Start Bootstrap</h1>

                <Divider color="divider-light"/>

                <p className="masthead-subheading font-weight-light mb-0">Graphic Artist - Web Designer - Illustrator</p>
            </div>
        </header>
    )
}

export default Main