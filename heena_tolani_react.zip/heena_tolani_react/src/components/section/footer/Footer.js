import Location from "./Location"
import Web from "./Web"
import Freelancer from "./Freelancer"

const Footer = () => {
    return (
        <div>
            <footer className="footer text-center">
                <div className="container">
                    <div className="row">
                        <Location />
                        <Web />
                        <Freelancer />
                    </div>
                </div>
            </footer>
            <div className="copyright py-4 text-center text-white">
                <div className="container"><small>Copyright &copy; Your Website 2023</small></div>
            </div>
        </div>
    )
}

export default Footer