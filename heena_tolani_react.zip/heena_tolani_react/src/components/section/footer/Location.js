const Location = () => {
    return (
    <div className="col-lg-4 mb-5 mb-lg-0">
        <h4 className="text-uppercase mb-4">Location</h4>
        <p className="lead mb-0">
            2215 John Daniel Drive
            <br />
            Clark, MO 65243
        </p>
    </div>
    )
}

export default Location