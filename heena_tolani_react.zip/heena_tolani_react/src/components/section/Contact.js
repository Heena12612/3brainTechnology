import TextBox from "../ui/TextBox"
import Divider from "../ui/Divider"

const Contact = () => {
  return (
    <section className="page-section" id="contact">
    <div className="container">
        
        <h2 className="page-section-heading text-center text-uppercase text-secondary mb-0">Contact Me</h2>
     
       <Divider color="" />
      
        <div className="row justify-content-center">
            <div className="col-lg-8 col-xl-7">
            
                <form id="contactForm" data-sb-form-api-token="API_TOKEN">
                  
                   <TextBox type="text" label="Full name" name="name" placeholder="Enter your name..."/>


                   <TextBox type="email" label="Email address" name="email" placeholder="name@example.com"/>
                   <TextBox type="tel" label="Phone number" name="phone" placeholder="(123) 456-7890"/>
                    
               
                      <div className="form-floating mb-3">
                        <textarea className="form-control" id="message" type="text" placeholder="Enter your message here..." style={{height: '10rem'}}data-sb-validations="required"></textarea>
                        <label for="message">Message</label>
                        <div className="invalid-feedback" data-sb-feedback="message:required">A message is required.</div>
                    </div>
                                   
                    <button className="btn btn-primary btn-xl disabled" id="submitButton" type="submit">Send</button>
                </form>
            </div>
        </div>
    </div>
</section>
  )
}

export default Contact