import { useState } from "react"
import PortfolioItem from "./PortfolioItem"
import PortfolioModel from "./PortfolioModel"
import Divider from "../../ui/Divider"

const Portfolio = () => {
    const [show, setShow] = useState(null)
    const Portfolioitems = [
        { id: 1, image: "assets/img/portfolio/cabin.png", title: "Log Cabin", modelID: "portfolioModel1" },
        { id: 2, image: "assets/img/portfolio/cake.png", title: "cake", modelID: "portfolioModel2" },
        { id: 3, image: "assets/img/portfolio/circus.png", title: "circus", modelID: "portfolioModel3" },
        { id: 4, image: "assets/img/portfolio/game.png", title: "game", modelID: "portfolioModel4" },
        { id: 5, image: "assets/img/portfolio/safe.png", title: "safe", modelID: "portfolioModel5" },
        { id: 6, image: "assets/img/portfolio/submarine.png", title: "submarine", modelID: "portfolioModel6" }
    ]

    return (
        <section className="page-section portfolio" id="portfolio">
            <div className="container">
                <h2 className="page-section-heading text-center text-uppercase text-secondary mb-0">Portfolio</h2>
                <Divider color="" />
                <div className="row justify-content-center">
                    {Portfolioitems.map((items, index) => {
                        return (<PortfolioItem key={index} image={items.image} modelID={items.modelID} setShow={setShow} item={items.id} />);

                    })}
                </div>
            </div>
            {Portfolioitems.map((items, index) => {
                return (<PortfolioModel key={index} image={items.image} title={items.title} modelID={items.modelID} show={show} item={items.id} setShow={setShow} />)
            })}

        </section>
    )
}

export default Portfolio